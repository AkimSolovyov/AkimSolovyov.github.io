<?php 
$data[] = $_REQUEST;
echo "<pre>";
var_dump($data);
