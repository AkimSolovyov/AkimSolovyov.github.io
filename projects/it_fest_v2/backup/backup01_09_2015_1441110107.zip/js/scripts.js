$(document).ready(function () {
    var animatedHeader = (function () {

        var docElem = document.documentElement,
            header = document.querySelector('.js-header'),
            didScroll = false,
            changeHeaderOn = 300;

        function init() {
            window.addEventListener('scroll', function (event) {
                if (!didScroll) {
                    didScroll = true;
                    setTimeout(scrollPage, 250);
                }
            }, false);
        }

        function scrollPage() {
            var sy = scrollY();
            if (sy >= changeHeaderOn) {
                $('.js-header').addClass('js-header-shrink');
            } else {
                $('.js-header').removeClass('js-header-shrink');
            }
            didScroll = false;
        }

        function scrollY() {
            return window.pageYOffset || docElem.scrollTop;
        }

        init();

    })();

    toggleForm();
    choosePanel();
    choosePath();

    $(".hidden-info-block").hide();

    $(".js-hidden-block-toggle").click(function () {
        $(".hidden-info-block").fadeToggle("slow", "linear");
        return false;
    });

    $("#speakers").owlCarousel({
        // Most important owl features
        items: 4,
        itemsCustom: false,
        itemsDesktop: [1200, 3],
        itemsDesktopSmall: [750, 2],
        itemsTablet: [550, 1],
        itemsTabletSmall: true,
        itemsMobile: [320, 1],
        singleItem: false,
        itemsScaleUp: false,

        //Basic Speeds
        slideSpeed: 200,
        paginationSpeed: 800,
        rewindSpeed: 1000,

        //Autoplay
        autoPlay: false,
        stopOnHover: false,

        // Navigation
        navigation: true,
        navigationText: ["", ""],
        rewindNav: true,
        scrollPerPage: false,

        //Pagination
        pagination: false,
        paginationNumbers: false,

        // Responsive
        responsive: true,
        responsiveRefreshRate: 200,
        responsiveBaseWidth: window,

        // CSS Styles
        baseClass: "owl-carousel",
        theme: "owl-theme",

        //Lazy load
        lazyLoad: false,
        lazyFollow: true,
        lazyEffect: "fade",


        //Mouse Events
        dragBeforeAnimFinish: true,
        mouseDrag: true,
        touchDrag: true,

    });


    $("#infopartners").owlCarousel({
        // Most important owl features
        items: 3,
        itemsCustom: false,
        itemsDesktop: [1200, 3],
        itemsDesktopSmall: [750, 2],
        itemsTablet: [550, 1],
        itemsTabletSmall: true,
        itemsMobile: [320, 1],
        singleItem: false,
        itemsScaleUp: false,

        //Basic Speeds
        slideSpeed: 200,
        paginationSpeed: 800,
        rewindSpeed: 1000,

        //Autoplay
        autoPlay: false,
        stopOnHover: false,

        // Navigation
        navigation: true,
        navigationText: ["", ""],
        rewindNav: true,
        scrollPerPage: false,

        //Pagination
        pagination: false,
        paginationNumbers: false,

        // Responsive
        responsive: true,
        responsiveRefreshRate: 200,
        responsiveBaseWidth: window,

        // CSS Styles
        baseClass: "owl-carousel",
        theme: "owl-theme",

        //Lazy load
        lazyLoad: false,
        lazyFollow: true,
        lazyEffect: "fade",


        //Mouse Events
        dragBeforeAnimFinish: true,
        mouseDrag: true,
        touchDrag: true,

    });

    $("#main-partners").owlCarousel({
        // Most important owl features
        items: 3,
        itemsCustom: false,
        itemsDesktop: [1200, 3],
        itemsDesktopSmall: [750, 2],
        itemsTablet: [550, 1],
        itemsTabletSmall: true,
        itemsMobile: [320, 1],
        singleItem: false,
        itemsScaleUp: false,

        //Basic Speeds
        slideSpeed: 200,
        paginationSpeed: 800,
        rewindSpeed: 1000,

        //Autoplay
        autoPlay: false,
        stopOnHover: false,

        // Navigation
        navigation: true,
        navigationText: ["", ""],
        rewindNav: true,
        scrollPerPage: false,

        //Pagination
        pagination: false,
        paginationNumbers: false,

        // Responsive
        responsive: true,
        responsiveRefreshRate: 200,
        responsiveBaseWidth: window,

        // CSS Styles
        baseClass: "owl-carousel",
        theme: "owl-theme",

        //Lazy load
        lazyLoad: false,
        lazyFollow: true,
        lazyEffect: "fade",


        //Mouse Events
        dragBeforeAnimFinish: true,
        mouseDrag: true,
        touchDrag: true,

    });

    $("#gold-partners").owlCarousel({
        // Most important owl features
        items: 3,
        itemsCustom: false,
        itemsDesktop: [1200, 3],
        itemsDesktopSmall: [750, 2],
        itemsTablet: [550, 1],
        itemsTabletSmall: true,
        itemsMobile: [320, 1],
        singleItem: false,
        itemsScaleUp: false,

        //Basic Speeds
        slideSpeed: 200,
        paginationSpeed: 800,
        rewindSpeed: 1000,

        //Autoplay
        autoPlay: false,
        stopOnHover: false,

        // Navigation
        navigation: true,
        navigationText: ["", ""],
        rewindNav: true,
        scrollPerPage: false,

        //Pagination
        pagination: false,
        paginationNumbers: false,

        // Responsive
        responsive: true,
        responsiveRefreshRate: 200,
        responsiveBaseWidth: window,

        // CSS Styles
        baseClass: "owl-carousel",
        theme: "owl-theme",

        //Lazy load
        lazyLoad: false,
        lazyFollow: true,
        lazyEffect: "fade",


        //Mouse Events
        dragBeforeAnimFinish: true,
        mouseDrag: true,
        touchDrag: true,

    });



    var m = new mandrill.Mandrill('PiO9LcolFIs57A1H2URuEQ');

    function log(obj) {
        $('#response').text(JSON.stringify(obj));
    }



    $('#sendEmail').click(function () {
        var name = $('.sign-up__name').val(),
            surname = $('.sign-up__surname').val(),
            phone = $('.sign-up__phone').val(),
            email = $('.sign-up__email').val(),
            date = new Date();

        date = date.toDateString();

        var params = {
            "message": {
                "from_email": "itfest@goit.com.ua",
                "to": [{
                    "email": "itfest@goit.com.ua"
            }],
                "subject": "Лиды с IT Fest " + date,
                "html": '<p>Имя:' + name + '<br>' +
                    'Фамилия:' + surname + '<br>' +
                    'Телефон:' + phone + '<br>' +
                    'Email:' + email + '</p>',
                'autotext': 'true',
                'track_opens': 'true'
            }
        };


        if ((name && surname && phone && email) !== '') {
            m.messages.send(params, function (res) {
                log(res);
            }, function (err) {
                log(err);
            });


            $('.sign-up-form-block').toggle();
            $('.curtain').toggle();

            if (ticketType == "online") {
                window.open("https://itfest-online.ticketforevent.com/ru/?draft_mode=on", '_blank');
            }

            window.open("https://itfest.ticketforevent.com/ru/?draft_mode=on", '_blank');
            $('.sign-up').trigger('reset');
            yaCounter31644913.reachGoal('key2');
            return false;
        }

    });


});


var ticketType = "offline";

function toggleForm() {
    $('.js-form-btn, .curtain').click(function () {
        $('.sign-up-form-block').toggle();
        $('.curtain').toggle();
        $('.sign-up__name').focus();
        if ($(this).hasClass("js-form-btn--online")) { //check if online ticket is chosen
            ticketType = "online";
        }
        return false;
    });
}

function show(id) {
    var h = $('.s' + id).offset().top;

    if (id != 1) {
        h = h - 45;
    }

    $("body,html").animate({
        "scrollTop": h
    }, 1000);

    if (id !== 10) {
        $(".icon").click();
    }
}


function choosePanel() {

    $('.timeline__btn').first().addClass('timeline__btn--chosen');
    $('.tickets__btn').first().addClass('tickets__btn--chosen');


    $('.timeline__btn').click(function () {
        $('.timeline__btn').removeClass('timeline__btn--chosen');
        $(this).addClass('timeline__btn--chosen');
    });

    $('.tickets__btn').click(function () {
        $('.tickets__btn').removeClass('tickets__btn--chosen');
        $(this).addClass('tickets__btn--chosen');
    });

    $('.js-main-stage').click(function () {
        $('.js-main-stage-panel').trigger('click');
    });

    $('.js-tech-stage').click(function () {
        $('.js-tech-stage-panel').trigger('click');
    });

    $('.js-interactive-area').click(function () {
        $('.js-interactive-area-panel').trigger('click');
    });

    $('.js-visit-us').click(function () {
        $('.js-visit-us-panel').trigger('click');
    });

    $('.js-online').click(function () {
        $('.js-online-panel').trigger('click');
    });

    $('.js-backup').click(function () {
        $('.js-backup-panel').trigger('click');
    });

    return false;
}

function choosePath() {
    $('.js-novice').click(function () {
        $('.js-main-stage').trigger('click');
        $('.teapot__box').addClass('teapot__box--active');
        $('.junior__box').removeClass('junior__box--active');
        $('.js-for-novice').css('opacity', '1');
        $('.js-for-junior').css('opacity', '0.2');
        show(10);

    });

    $('.js-junior').click(function () {
        $('.js-main-stage').trigger('click');
        $('.teapot__box').removeClass('teapot__box--active');
        $('.junior__box').addClass('junior__box--active');
        $('.js-for-junior').css('opacity', '1');
        $('.js-for-novice').css('opacity', '0.2');
        show(10);

    });

}


$(document).ready(function () {
    $(".icon").click(function () {
        $(".icon").toggleClass('icon--cross');
        $(".mobilenav").fadeToggle(500);
        $(".top-menu").toggleClass("top-animate");
        $("body").toggleClass("noscroll");
        $(".mid-menu").toggleClass("mid-animate");
        $(".bottom-menu").toggleClass("bottom-animate");
    });
});

// PUSH ESC KEY TO EXIT

$(document).keydown(function (e) {
    if (e.keyCode == 27) {
        $(".mobilenav").fadeOut(500);
        $(".top-menu").removeClass("top-animate");
        $("body").removeClass("noscroll");
        $(".mid-menu").removeClass("mid-animate");
        $(".bottom-menu").removeClass("bottom-animate");
    }
});